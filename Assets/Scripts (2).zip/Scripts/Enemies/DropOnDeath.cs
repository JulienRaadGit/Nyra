using UnityEngine;

public class DropOnDeath : MonoBehaviour {
    public GameObject xpOrbPrefab;
    public int xpMin = 1, xpMax = 1;

    void Start(){
        if (TryGetComponent<Damageable>(out var d)) 
            d.OnDeath += OnDied;
    }

    void OnDied(Damageable d){
        int count = Random.Range(xpMin, xpMax + 1);
        for (int i = 0; i < count; i++) {
            var offset = Random.insideUnitCircle * 0.3f;
            // ⚡ Utilise la rotation du prefab au lieu de Quaternion.identity
            Instantiate(
                xpOrbPrefab, 
                d.transform.position + (Vector3)offset, 
                xpOrbPrefab.transform.rotation
            );
        }
    }
}
