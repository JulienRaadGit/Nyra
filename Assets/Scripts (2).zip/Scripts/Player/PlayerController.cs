using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour {
    public float moveSpeed = 3f;
    public Vector2 boundsMin = new(-40,-40), boundsMax = new(40,40);
    public VirtualJoystick joystick;
    Rigidbody2D rb; Vector2 input;

    void Awake(){ rb = GetComponent<Rigidbody2D>(); Application.targetFrameRate=60; }
    void Update(){
        input = joystick ? joystick.Direction : new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
    }

    void FixedUpdate(){
        float mult = PlayerStats.Instance ? PlayerStats.Instance.moveSpeedMult : 1f;
        Vector2 target = rb.position + input.normalized * (moveSpeed * mult) * Time.fixedDeltaTime;
        target.x = Mathf.Clamp(target.x, boundsMin.x, boundsMax.x);
        target.y = Mathf.Clamp(target.y, boundsMin.y, boundsMax.y);
        rb.MovePosition(target);
    }
}
