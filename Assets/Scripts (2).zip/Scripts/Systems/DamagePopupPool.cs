using UnityEngine;
using System.Collections.Generic;

public class DamagePopupPool : MonoBehaviour
{
    public static DamagePopupPool I { get; private set; }

    public DamagePopup prefab;
    readonly Queue<DamagePopup> q = new Queue<DamagePopup>();

    void Awake()
    {
        if (I && I != this) { Destroy(gameObject); return; }
        I = this;
    }

    DamagePopup Get()
    {
        if (q.Count > 0)
        {
            var p = q.Dequeue();
            p.gameObject.SetActive(true);
            return p;
        }
        return Instantiate(prefab, transform);
    }

    public void Despawn(DamagePopup p)
    {
        p.gameObject.SetActive(false);
        q.Enqueue(p);
    }

    public void Spawn(Vector3 worldPos, int amount, bool crit = false)
    {
        if (!prefab) { Debug.LogWarning("[DamagePopupPool] Prefab non assigné."); return; }
        var p = Get();
        p.transform.position = worldPos;
        p.Setup(amount, crit, this);
    }
}
