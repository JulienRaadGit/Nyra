using UnityEngine;
using TMPro;

public class DamagePopup : MonoBehaviour
{
    [SerializeField] TextMeshPro tmp;
    [SerializeField] float lifetime = 0.6f;
    [SerializeField] float floatSpeed = 1.5f;
    [SerializeField] Vector2 randomSpread = new Vector2(0.25f, 0.15f);
    [SerializeField] float punchScale = 1.15f;

    DamagePopupPool pool;
    float t;
    Color baseColor;
    Vector3 startPos;
    Vector3 startScale;

    public void Setup(int amount, bool crit, DamagePopupPool owner)
    {
        pool = owner;
        if (!tmp) tmp = GetComponent<TextMeshPro>();

        tmp.text = amount.ToString();
        tmp.fontSize = crit ? 6f : 4f;
        tmp.enableWordWrapping = false;

        // Couleur: blanc, critique en jaune/orangé
        tmp.color = crit ? new Color(1f, 0.85f, 0.25f, 1f) : new Color(1f, 1f, 1f, 1f);
        baseColor = tmp.color;

        startPos = transform.position;
        // petit offset aléatoire
        startPos += (Vector3)new Vector2(Random.Range(-randomSpread.x, randomSpread.x),
                                         Random.Range(0f, randomSpread.y));
        transform.position = startPos;

        startScale = Vector3.one * (crit ? 1.2f : 1f);
        transform.localScale = startScale * punchScale;

        t = 0f;
        gameObject.SetActive(true);
    }

    void Update()
    {
        t += Time.deltaTime;
        // montée
        transform.position += Vector3.up * floatSpeed * Time.deltaTime;

        // easing scale -> revient à 1
        float s = Mathf.Lerp(punchScale, 1f, t / 0.15f);
        transform.localScale = startScale * s;

        // fade
        float a = Mathf.Clamp01(1f - (t / lifetime));
        var c = baseColor; c.a = a; tmp.color = c;

        if (t >= lifetime)
            pool.Despawn(this);
    }
}
