using UnityEngine;

public class HealthBar : MonoBehaviour
{
    [SerializeField] Transform fill;                 // glisse "Fill" ici
    [SerializeField] Vector3 localOffset = new Vector3(0f, 1.1f, 0f);

    Transform target; 
    Vector3 fillBaseScale;
    Vector3 fillBasePos;

    void Reset()
    {
        // auto-assign "Fill" si trouvé
        var f = transform.Find("Fill");
        if (f) fill = f;
    }

    void Awake()
    {
        // 1) Choisir la cible
        //   - priorité: parent actuel
        //   - sinon: GameObject taggué "Player"
        target = transform.parent;
        if (!target)
        {
            var player = GameObject.FindGameObjectWithTag("Player");
            if (player) target = player.transform;
        }

        // 2) Forcer le parentage au Player (si pas déjà fait)
        if (target)
        {
            if (transform.parent != target)
                transform.SetParent(target, worldPositionStays: false);

            transform.localPosition = localOffset;
        }
        else
        {
            Debug.LogWarning("[HealthBar] Aucune cible trouvée (pas de parent ni d'objet tag 'Player'). La barre ne suivra pas.");
        }

        // 3) Mémoriser l'état de Fill pour la réduction par la gauche
        if (fill)
        {
            fillBaseScale = fill.localScale;
            fillBasePos   = fill.localPosition;
        }
        else
        {
            Debug.LogWarning("[HealthBar] 'fill' non assigné.");
        }
    }

    void LateUpdate()
    {
        // Maintenir l'offset local (utile si scale change)
        if (target)
            transform.localPosition = localOffset;
    }

    public void SetRatio(float ratio)
    {
        ratio = Mathf.Clamp01(ratio);
        if (!fill) return;

        float newX = fillBaseScale.x * ratio;
        float delta = (fillBaseScale.x - newX) * 0.5f;
        fill.localScale    = new Vector3(newX, fillBaseScale.y, fillBaseScale.z);
        fill.localPosition = new Vector3(fillBasePos.x - delta, fillBasePos.y, fillBasePos.z);
    }
}
