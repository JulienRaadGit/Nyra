using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class LevelUpUI : MonoBehaviour {
    public GameObject panel;
    public Button[] buttons;
    public TextMeshProUGUI[] labels;

    List<UpgradeId> current;

    public void Show(List<UpgradeId> offer){
        current = offer;
        panel.SetActive(true);
        Time.timeScale = 0f;

        for (int i = 0; i < buttons.Length; i++){
            bool on = i < offer.Count;
            buttons[i].gameObject.SetActive(on);
            if (!on) continue;

            // AU LIEU de: labels[i].text = UpgradeSystem.Title(offer[i]);
            labels[i].text = UpgradeSystem.Instance.Label(offer[i]);

            int k = i;
            buttons[i].onClick.RemoveAllListeners();
            buttons[i].onClick.AddListener(()=>Pick(k));
        }
    }

    void Pick(int i){
        panel.SetActive(false);
        Time.timeScale = 1f;
        if (i>=0 && i<current.Count) UpgradeSystem.Instance.Pick(current[i]);
    }
}
