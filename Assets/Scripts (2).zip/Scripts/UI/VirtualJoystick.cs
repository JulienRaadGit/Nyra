using UnityEngine;
using UnityEngine.EventSystems;

public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler {
    public RectTransform handle, background;
    public float maxRadius = 60f;
    public Vector2 Direction { get; private set; }

    public void OnPointerDown(PointerEventData e){ OnDrag(e); }
    public void OnPointerUp(PointerEventData e){ handle.anchoredPosition = Vector2.zero; Direction = Vector2.zero; }
    public void OnDrag(PointerEventData e){
        RectTransformUtility.ScreenPointToLocalPointInRectangle(background, e.position, e.pressEventCamera, out var local);
        local = Vector2.ClampMagnitude(local, maxRadius);
        handle.anchoredPosition = local;
        Direction = local / maxRadius;
    }
}
