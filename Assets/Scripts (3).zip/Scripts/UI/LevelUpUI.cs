using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class LevelUpUI : MonoBehaviour {
    public GameObject panel;
    public Button[] buttons;
    public TextMeshProUGUI[] labels;

    List<UpgradeId> current;

    void Awake(){
        if (!panel) Debug.LogError("[LevelUpUI] 'panel' non assigné (racine LevelUpPanel).");
    }

    public void Show(List<UpgradeId> offer){
        current = offer ?? new List<UpgradeId>();

        // Ouvre en modal via le routeur (coupe joystick + force raycasts + met au-dessus)
        if (!panel){ Debug.LogError("[LevelUpUI] Panel manquant."); return; }
        UIRaycastRouter.Instance?.ShowModal(panel, sortingOrder: 700);

        // Pause
        Time.timeScale = 0f;

        // Configure les cartes
        for (int i = 0; i < buttons.Length; i++){
            bool on = i < current.Count;
            buttons[i].gameObject.SetActive(on);
            if (!on) continue;

            labels[i].text = UpgradeSystem.Instance.Label(current[i]);

            int k = i;
            buttons[i].onClick.RemoveAllListeners();
            buttons[i].onClick.AddListener(()=>Pick(k));
        }

        Debug.Log("[LevelUpUI] Panel ouvert (via router).");
    }

    void Pick(int i){
        // Ferme le modal + reprend le temps
        UIRaycastRouter.Instance?.HideModal(panel);
        Time.timeScale = 1f;

        if (i>=0 && i<current.Count) UpgradeSystem.Instance.Pick(current[i]);
    }
}
