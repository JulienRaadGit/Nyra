using UnityEngine;
using System.Collections.Generic;

/// Arme d’orbes en orbite autour du joueur. Niveaux 1..5 : +1 orbe/level, +rayon, +dégâts.
public class Orbit : MonoBehaviour
{
    [Header("Refs")]
    public Transform player;       // assigné par WeaponManager
    public GameObject orbPrefab;   // ton prefab "Orbits" (Sprite + CircleCollider2D isTrigger + Rigidbody2D Kinematic)

    [Header("Stats")]
    [Range(1,5)] public int level = 1;
    public int maxLevel = 5;

    public float baseDamage = 10f;
    public float damagePerLevel = 4f;

    public float baseRadius = 1.6f;
    public float radiusPerLevel = 0.2f;

    public float rotationSpeedDegPerSec = 120f;
    public bool clockwise = true;

    [Header("FX/Options")]
    public bool scaleOrbsWithLevel = true;

    readonly List<GameObject> _orbs = new();
    float _currentRadius;

    void Awake()
    {
        if (!player && transform.parent != null) player = transform.root;
    }

    void Update()
    {
        if (!player) return;
        transform.position = player.position;

        float dir = clockwise ? -1f : 1f;
        transform.Rotate(0f, 0f, dir * rotationSpeedDegPerSec * Time.deltaTime);
    }

    // Appelé par WeaponManager
    public void Init(Transform playerRef, GameObject orbPrefabRef, int startLevel = 1)
    {
        player = playerRef;
        orbPrefab = orbPrefabRef;
        level = Mathf.Clamp(startLevel, 1, maxLevel);
        Rebuild();
    }

    public bool CanLevelUp() => level < maxLevel;

    public void LevelUp()
    {
        if (!CanLevelUp()) return;
        level++;
        Rebuild();
    }

    public void SetLevel(int targetLevel)
    {
        level = Mathf.Clamp(targetLevel, 1, maxLevel);
        Rebuild();
    }

    void Rebuild()
    {
        // clear anciens orbes
        for (int i = _orbs.Count - 1; i >= 0; i--)
            if (_orbs[i]) Destroy(_orbs[i]);
        _orbs.Clear();

        int orbCount = Mathf.Clamp(level, 1, maxLevel);
        _currentRadius = baseRadius + (level - 1) * radiusPerLevel;
        float damage = baseDamage + (level - 1) * damagePerLevel;

        for (int i = 0; i < orbCount; i++)
        {
            float angle = (360f / orbCount) * i;
            Vector3 localPos = AngleToLocalPosition(angle, _currentRadius);

            var orb = Instantiate(orbPrefab, transform);
            orb.transform.localPosition = localPos;

            if (scaleOrbsWithLevel)
            {
                float s = 1f + 0.06f * (level - 1);
                orb.transform.localScale = new Vector3(s, s, 1f);
            }

            var dot = orb.GetComponent<DamageOnTouch>();
            if (dot != null)
            {
                dot.damage = damage;
                dot.owner = this; // utile pour ignorer le joueur
            }

            _orbs.Add(orb);
        }
    }

    Vector3 AngleToLocalPosition(float angleDeg, float radius)
    {
        float rad = angleDeg * Mathf.Deg2Rad;
        return new Vector3(Mathf.Cos(rad) * radius, Mathf.Sin(rad) * radius, 0f);
    }
}
