using UnityEngine;

public class Damageable : MonoBehaviour {
    [Header("Health")]
    public float maxHP = 3f;
    private float hp;

    // Événement appelé à la mort
    public System.Action<Damageable> OnDeath;

    void Awake() {
        hp = maxHP;
    }

    public void Take(float dmg) {
        hp -= dmg;
        if (hp <= 0) {
            Die();
        }
    }

    private void Die() {
        OnDeath?.Invoke(this);   // avertit les autres scripts (DropOnDeath, etc.)
        Destroy(gameObject);
    }
}
