using UnityEngine;

public class AutoAimShooter : MonoBehaviour {
    public Projectile projectilePrefab;
    public float fireRate = 2f;
    public float range = 10f;

    private float cooldown;

    void Update() {
        cooldown -= Time.deltaTime;
        if (cooldown > 0) return;

        Transform target = FindClosestEnemy();
        if (!target) return;

        Vector2 dir = (target.position - transform.position).normalized;
        var proj = Instantiate(projectilePrefab);
        proj.Fire(transform.position, dir);

        cooldown = 1f / fireRate;
    }

    Transform FindClosestEnemy() {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
        Transform closest = null;
        float minDist = Mathf.Infinity;

        foreach (var e in enemies) {
            float d = (e.transform.position - transform.position).sqrMagnitude;
            if (d < range * range && d < minDist) {
                minDist = d;
                closest = e.transform;
            }
        }
        return closest;
    }
}
