using UnityEngine;

public class WeaponManager : MonoBehaviour {
    public Transform weaponParent; // un Empty attaché au Player
    public GameObject auraPrefab;

    Aura auraInstance;

    public void AddAura(){
        if (auraInstance) return; // déjà équipé
        var go = Instantiate(auraPrefab, weaponParent);
        go.transform.localPosition = Vector3.zero;
        auraInstance = go.GetComponent<Aura>();
    }

    public void UpgradeAura(){
        if (!auraInstance) return;
        auraInstance.damagePerSecond += 2f;  // chaque upgrade : +2 DPS
        var c = auraInstance.GetComponent<CircleCollider2D>();
        c.radius += 0.5f;                    // l’aura grandit
    }
}
