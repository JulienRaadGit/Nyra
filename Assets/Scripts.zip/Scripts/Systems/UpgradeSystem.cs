using UnityEngine;
using System.Collections.Generic;

public class UpgradeSystem : MonoBehaviour {
    public static UpgradeSystem Instance;
    public LevelUpUI ui;

    void Awake(){
        Instance = this;
        if (LevelSystem.Instance) LevelSystem.Instance.OnLevelUp += Offer;
    }

    void OnDestroy(){
        if (LevelSystem.Instance) LevelSystem.Instance.OnLevelUp -= Offer;
    }

    void Offer(){
        // 3 intitulés temporaires; on branchera de vrais pouvoirs après
        var pool = new List<string>{ "Cadence ↑", "Dégâts ↑", "Portée ↑", "Taille projectile ↑", "Vitesse move ↑" };
        var offer = new List<string>();
        for (int i=0; i<3 && pool.Count>0; i++){
            int k = Random.Range(0, pool.Count);
            offer.Add(pool[k]);
            pool.RemoveAt(k);
        }
        ui.Show(offer);
    }
}
