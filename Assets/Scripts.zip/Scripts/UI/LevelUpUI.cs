using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class LevelUpUI : MonoBehaviour {
    public GameObject panel;          // LevelUpPanel
    public Button[] buttons;          // BtnA/B/C
    public TextMeshProUGUI[] labels;  // LabelA/B/C

    List<string> current;

    public void Show(List<string> offer){
        current = offer;
        panel.SetActive(true);
        Time.timeScale = 0f;
        for (int i = 0; i < buttons.Length; i++){
            bool on = i < offer.Count;
            buttons[i].gameObject.SetActive(on);
            if (!on) continue;
            labels[i].text = offer[i];
            int k = i;
            buttons[i].onClick.RemoveAllListeners();
            buttons[i].onClick.AddListener(()=>Pick(k));
        }
    }

    void Pick(int i){
        panel.SetActive(false);
        Time.timeScale = 1f;
        // TODO: on appliquera le pouvoir choisi ici quand ils seront prêts
    }
}
