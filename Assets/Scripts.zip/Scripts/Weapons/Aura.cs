using UnityEngine;

public class Aura : MonoBehaviour {
    public float damagePerSecond = 3f;

    void OnTriggerStay2D(Collider2D col){
        if (col.TryGetComponent<Damageable>(out var d)){
            d.Take(damagePerSecond * Time.deltaTime);
        }
    }
}
